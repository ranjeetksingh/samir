package com.ubs.javatest;

import java.io.File;
import java.math.BigDecimal;
import java.net.URI;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ubs.javatest.model.CompanyModel;
import com.ubs.javatest.service.AverageCalcualtionService;
import com.ubs.javatest.service.CurrencyService;
import com.ubs.javatest.service.DataReadService;

public class Main {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		try {

			ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

			URI location = Main.class.getClassLoader().getResource("FILE.DAT").toURI();
			File file = new File(location.getPath());

			DataReadService dataService = (DataReadService) context.getBean("datareadservice");

			CurrencyService currService = (CurrencyService) context.getBean("currencyservice");
			
			List<CompanyModel> companyObj = dataService.read(file.getPath());
			AverageCalcualtionService calcService = (AverageCalcualtionService) context.getBean("averagecalculation");
			Map<String, BigDecimal> result = calcService.calculate(currService,companyObj);

			for (Map.Entry<String, BigDecimal> entry : result.entrySet()) {
				String[] token = entry.getKey().split("_");
				System.out.println(
						"COUNTRY:" + token[0] + " RATING:" + token[1] + "  AVERAGE IN EURO: " + entry.getValue());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}