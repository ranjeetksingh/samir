package com.ubs.javatest.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.stereotype.Service;

import com.ubs.javatest.model.CompanyModel;

/*
 * Data read service
 */
@Service("datareadservice")
public class DataReadService {

	private String DEL = "\t";

	/**
	 * 
	 * @param path
	 * @return
	 * @throws Exception
	 */
	public List<CompanyModel> read(String path) throws Exception {
		Scanner reader = null;

		List<CompanyModel> dataList = null;
		try {

			File file = new File(path);
			reader = new Scanner(file);

			reader.nextLine();
			dataList = new ArrayList<CompanyModel>();
			while (reader.hasNextLine()) {
				dataList.add(extractData(reader.nextLine()));
			}
		} catch (FileNotFoundException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		} finally {
			if (reader != null)
				reader.close();
		}
		return dataList;
	}

	/**
	 * 
	 * @param line
	 * @return
	 */
	private CompanyModel extractData(String line) {

		String[] data = line.split(DEL);

		CompanyModel model = new CompanyModel();
		model.setCompanyCode(data[0]);
		model.setAccount(data[1]);
		model.setCity(data[2]);
		model.setCountry(data[3]);
		model.setCreditRating(data[4]);
		model.setCurrency(data[5]);
		model.setAmount(data[6]);

		return model;
	}
}
