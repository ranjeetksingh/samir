package com.ubs.javatest.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.ubs.javatest.model.CompanyModel;

/**
 *  Average calculation Service
 */
@Service("averagecalculation")
public class AverageCalcualtionService {
	
	/*
	 * 
	 */
	public Map<String, BigDecimal>  calculate(CurrencyService currServ,List<CompanyModel> dataList) throws Exception{

		Map<String, List<CompanyModel>> compRatingGroupedDat = new HashMap<String, List<CompanyModel>>();
		
		for(CompanyModel data :dataList){
			
			String groupKey = "";
			
			if(data.getCountry() != null &&  !data.getCountry().isEmpty() ){
				groupKey = data.getCountry()+"_"+data.getCreditRating().trim();
			}
			else{				
				groupKey = data.getCity()+"_"+data.getCreditRating().trim();
			}
			
			if(compRatingGroupedDat.containsKey(groupKey)){
				compRatingGroupedDat.get(groupKey).add(data);				
			}else{				
				ArrayList<CompanyModel> compList = new ArrayList<CompanyModel>();
				compList.add(data);
				compRatingGroupedDat.put(groupKey, compList);
			}				
		}
		
		Map<String, BigDecimal> result = new HashMap<String, BigDecimal>();

		for(String key : compRatingGroupedDat.keySet()){
						
			result.put(key, calculateAverage(compRatingGroupedDat.get(key),currServ));
		}
		
		return result; 
	}
	
	/**
	 * 
	 * @param groupeddata
	 * @param currServ
	 * @return
	 * @throws Exception
	 */
	private BigDecimal calculateAverage(List<CompanyModel> groupeddata,CurrencyService currServ) throws Exception {

		BigDecimal result = BigDecimal.ZERO;
		for(CompanyModel compInfo : groupeddata){
			
			BigDecimal amtInEuro = currServ.convertCurrency(compInfo.getCurrency(), new BigDecimal(compInfo.getAmount()));
			result = result.add(amtInEuro);
		}
		// convert to euro
		result = result.divide(new BigDecimal(groupeddata.size()), 2, RoundingMode.HALF_UP);
		
		return result;
	}
	
}
