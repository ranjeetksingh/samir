package com.ubs.javatest.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;

import org.springframework.stereotype.Service;

/*
 * currency conversion service
 */
@Service("currencyservice")
public class CurrencyService {

	private HashMap<String, BigDecimal> rateMap = new HashMap<String, BigDecimal>();

	/**
	 * 
	 */
	public CurrencyService() {
		rateMap.put("GBP", new BigDecimal(1.654f));
		rateMap.put("CHF", new BigDecimal(1.10f));
		rateMap.put("EUR", new BigDecimal(1.35f));
	}


	/**
	 * 
	 * @param currency
	 * @param amount
	 * @return
	 * @throws Exception
	 */
	public BigDecimal convertCurrency(String currency, BigDecimal amount) throws Exception {

		if (!rateMap.containsKey(currency)){
			throw new Exception("Invalid currency -> "+currency);
		}
		
		BigDecimal usd = amount.multiply(rateMap.get(currency));
		
		return usd.divide(rateMap.get("EUR"),2, RoundingMode.HALF_UP);
	}
}
