package com.ubs.javatest.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.io.File;
import java.net.URI;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.ubs.javatest.Main;
import com.ubs.javatest.model.CompanyModel;
import com.ubs.javatest.service.DataReadService;

public class TestDataRead {

	DataReadService dataSvc;
	
	@Before
	public void before() throws Exception {
		dataSvc = new DataReadService();
	}
	
	
	@Test 
	public void testDataReadSize()throws Exception{
		URI location = Main.class.getClassLoader().getResource("FILE.DAT").toURI();
		File file = new File(location.getPath());
		
		List<CompanyModel> companyObj = dataSvc.read(file.getPath());
		assertThat(companyObj.size(),  is(19) );

	}
	

	
	@Test 
	public void testDataLoadService_DataMatch()throws Exception{
		
		URI location = Main.class.getClassLoader().getResource("FILE.DAT").toURI();
		File file = new File(location.getPath());
		
		List<CompanyModel> companyObj = dataSvc.read(file.getPath());
		
		assertThat(companyObj.get(18).getCompanyCode(),  is("2318") );
		assertThat(companyObj.get(18).getAccount(),  is("8084107") );
		assertThat(companyObj.get(18).getAmount(),  is("836211889.9") );
		assertThat(companyObj.get(18).getCity(),  is("Bangalore") );
		assertThat(companyObj.get(18).getCountry(),  is("IND") );
		assertThat(companyObj.get(18).getCreditRating(),  is("Aaa+") );
		assertThat(companyObj.get(18).getCurrency(),  is("CHF") );

	}
	
	@Test 
	public void testDataReadZeroSize() throws Exception{
		URI location = Main.class.getClassLoader().getResource("ZERO.DAT").toURI();
		File file = new File(location.getPath());
		
		List<CompanyModel> companyObj = dataSvc.read(file.getPath());
		assertThat(companyObj.size(),  is(0) );
	}	
}
