package com.ubs.javatest.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.ubs.javatest.model.CompanyModel;
import com.ubs.javatest.service.AverageCalcualtionService;
import com.ubs.javatest.service.CurrencyService;

public class TestCalculator {

	AverageCalcualtionService calculationSvc;
	CurrencyService currencySvc;
	
	@Before
	public void before() throws Exception {
		calculationSvc = new AverageCalcualtionService();
		currencySvc = new CurrencyService();
	}
	
	
	@Test 
	public void TestAverage() throws Exception{
		
		ArrayList<CompanyModel> dataList = new ArrayList<CompanyModel>();
		
		CompanyModel data0 = new CompanyModel();
		data0.setCountry("IND");
		data0.setCreditRating("ABA-");
		data0.setAmount("607295781.3");
		data0.setCurrency("CHF");
		dataList.add(data0);

		
		CompanyModel data1 = new CompanyModel();
		data1.setCountry("IND");
		data1.setCreditRating("ABA-");
		data1.setAmount("603000673.3");
		data1.setCurrency("GBP");
		dataList.add(data1);		

		Map<String, BigDecimal>  result = calculationSvc.calculate(currencySvc,dataList);
		
		assertThat(result.entrySet().size(),  is(1) );
		
		BigDecimal calculatedAvg = result.entrySet().iterator().next().getValue();
		
		BigDecimal expAverage = currencySvc.convertCurrency("CHF", new BigDecimal("607295781.3"))
				.add(currencySvc.convertCurrency("GBP", new BigDecimal("603000673.3")))
				.divide(new BigDecimal(2), 2, RoundingMode.HALF_UP);
		
		assertTrue(calculatedAvg.compareTo(expAverage) == 0);
	}

	@Test 
	public void TestCityNameForMissingCountry() throws Exception{
		
		ArrayList<CompanyModel> dataList = new ArrayList<CompanyModel>();
		CompanyModel data0 = new CompanyModel();
		data0.setCountry("");
		data0.setCity("nyc");
		data0.setCreditRating("BBB");
		data0.setAmount("0");
		data0.setCurrency("GBP");
		
		dataList.add(data0);
	

		Map<String, BigDecimal>  result = calculationSvc.calculate(currencySvc,dataList);
		
		assertThat(result.entrySet().size(),  is(1) );
		
		String key = result.entrySet().iterator().next().getKey();
		
		assertThat(key.split("_")[0],  is("nyc") );
		
	}	
}
