package com.ubs.javatest.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	TestCalculator.class,
	TestCurrencyConversion.class,
	TestDataRead.class
})
public class Test {
	
	
}
