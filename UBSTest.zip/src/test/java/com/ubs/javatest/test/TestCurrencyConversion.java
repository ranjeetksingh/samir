package com.ubs.javatest.test;

import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.junit.Before;
import org.junit.Test;

import com.ubs.javatest.service.CurrencyService;

public class TestCurrencyConversion {

	CurrencyService service;

	
	@Before
	public void before() throws Exception {
		 service = new CurrencyService();
	}

	@Test(expected = Exception.class)
	public void testNotSupportedCurrency() throws Exception{		
		service.convertCurrency("AUS", new BigDecimal(1000));
	}
	
	@Test 
	public void testCurrencyConversion_GBP() throws Exception{

		BigDecimal amt = service.convertCurrency("GBP", new BigDecimal(1000));		
		BigDecimal expectedAmt = new BigDecimal(1000).multiply(new BigDecimal(1.654)).divide(new BigDecimal(1.35),2,RoundingMode.HALF_UP);
		assertTrue(amt.compareTo(expectedAmt) == 0);
	}

	@Test 
	public void testCurrencyConversion_CHF() throws Exception{

		BigDecimal amt = service.convertCurrency("CHF", new BigDecimal(1000));		
		BigDecimal expectedAmt = new BigDecimal(1000).multiply(new BigDecimal(1.10)).divide(new BigDecimal(1.35),2,RoundingMode.HALF_UP);
		assertTrue(amt.compareTo(expectedAmt) == 0);
	}

	@Test 
	public void testCurrencyConversion_EUR() throws Exception{

		BigDecimal amt = service.convertCurrency("EUR", new BigDecimal(1000));		
		BigDecimal expectedAmt = new BigDecimal(1000).multiply(new BigDecimal(1.35)).divide(new BigDecimal(1.35),2,RoundingMode.HALF_UP);
		assertTrue(amt.compareTo(expectedAmt) == 0);
	}
	
}
